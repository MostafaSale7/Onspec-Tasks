﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Age_Calculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void calculateAge(object sender, RoutedEventArgs e)
        {
            if (checkIfDateSelected(datePicker.SelectedDate.Value)){
              resultAge.Content =  caluclateAge(datePicker.SelectedDate.Value);
            }
            else{
                MessageBox.Show("Kindly Select a Real date becuse you entard a date not come yet");
            }
        }
        public bool checkIfDateSelected(DateTime selectedDate)
        {
           if(selectedDate < DateTime.Now) {
                return true;
            }
            return false;
        }
        public string caluclateAge(DateTime dateOfBirth)
        {
            string currentAge = "";
            int birthYear = calculateYears(dateOfBirth.Year); 
            int birthMonth = calculateMonthes(dateOfBirth.Month);
            int birthDay = calculateDays(dateOfBirth.Day);
            currentAge += "Your Age is " + birthYear.ToString() + " Years and " + birthMonth.ToString() + " Months and " + birthDay.ToString() + " Days";
            return currentAge;
        }
        public int calculateYears(int birthYear){ 
            return ((DateTime.Now.Year - 1) - birthYear);// we deduct 1 year from current year to add it on monthes
        }
        public int calculateMonthes(int birthMonth){
            return ((DateTime.Now.Month + 12) - birthMonth); // we add 12 month as 1 year to have remaing monthes
        }
        public int calculateDays(int birthDay){
            int currentDate = DateTime.Now.Day - birthDay;
            if (currentDate < 0){
                return currentDate * -1;
            }
            return currentDate;
        }
    }
}
